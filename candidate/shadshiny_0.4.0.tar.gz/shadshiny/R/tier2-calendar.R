# calendar & date-picker -------------------------------------------------------

# Serialize a Date / character to ISO-8601 (YYYY-MM-DD), or NULL.
.iso_date <- function(x) {
  if (is.null(x) || length(x) == 0) return(NULL)
  x <- x[[1]]
  if (inherits(x, "Date")) return(format(x, "%Y-%m-%d"))
  format(as.Date(x), "%Y-%m-%d")
}

#' Calendar
#'
#' A shadcn calendar. The month grid is rendered client-side from the seed
#' attributes. `input$<inputId>` is a `Date` (single) or length-2 `Date`
#' (range), via the `shadshiny.date` input handler.
#'
#' @param inputId Input id.
#' @param value Initial selection: a `Date`/character (single) or length-2
#'   `Date`/character (range).
#' @param mode `"single"` (default) or `"range"`.
#' @param min,max Selectable bounds (inclusive), `Date`/character.
#' @param month Initially displayed month (`Date` or `"YYYY-MM"`). Sets the
#'   month the grid opens on without selecting anything.
#' @param caption_layout Header style: `"label"` (default, month and year as
#'   text), `"dropdown"` (both as selects), `"dropdown-months"` or
#'   `"dropdown-years"`. Use a dropdown when the user has to travel years, such
#'   as a date of birth.
#' @param year_range Length-2 numeric bounding the year dropdown, e.g.
#'   `c(1900, 2025)`. Defaults to the years of `min`/`max` when given, otherwise
#'   100 years back and 10 forward.
#' @param week_starts_on `0` (Sunday, default) or `1` (Monday).
#' @param disabled If `TRUE`, disables the control.
#' @param class Extra CSS classes.
#' @param ... Extra attributes on the calendar root.
#' @returns A calendar tag.
#' @family shadshiny tier-2 components
#' @examples
#' shad_calendar("day", value = Sys.Date())
#' shad_calendar("range", mode = "range", week_starts_on = 1)
#' shad_calendar("dob", caption_layout = "dropdown", year_range = c(1900, 2025))
#' @export
shad_calendar <- function(inputId, value = NULL, mode = c("single", "range"),
                          min = NULL, max = NULL, month = NULL,
                          caption_layout = c("label", "dropdown",
                                             "dropdown-months", "dropdown-years"),
                          year_range = NULL,
                          week_starts_on = 0, disabled = FALSE, class = NULL,
                          ...) {
  if (!is.null(inputId)) value <- shiny::restoreInput(id = inputId, default = value)
  mode <- arg_match_shad(mode, c("single", "range"), "mode")
  caption_layout <- arg_match_shad(
    caption_layout,
    c("label", "dropdown", "dropdown-months", "dropdown-years"),
    "caption_layout"
  )
  if (!is.null(year_range) && length(year_range) != 2) {
    stop("`year_range` must be a length-2 numeric vector.", call. = FALSE)
  }
  v_start <- if (!is.null(value)) .iso_date(value[[1]]) else NULL
  v_end <- if (mode == "range" && length(value) >= 2) .iso_date(value[[2]]) else NULL
  month_attr <- if (!is.null(month)) {
    if (inherits(month, "Date")) format(month, "%Y-%m") else as.character(month)
  }

  with_deps(htmltools::tags$div(
    class = shad_class("shad-calendar", extra = class),
    `data-shad` = "calendar",
    id = inputId,
    `data-mode` = mode,
    `data-value` = v_start,
    `data-value-end` = v_end,
    `data-min` = .iso_date(min),
    `data-max` = .iso_date(max),
    `data-week-start` = as.integer(week_starts_on),
    `data-month` = month_attr,
    `data-caption-layout` = if (caption_layout != "label") caption_layout,
    `data-from-year` = if (!is.null(year_range)) as.integer(year_range[[1]]),
    `data-to-year` = if (!is.null(year_range)) as.integer(year_range[[2]]),
    `data-disabled` = flag_attr(disabled),
    ...
  ))
}

.shad_date_picker_icon <- htmltools::HTML(paste0(
  '<svg class="shad-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" ',
  'stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ',
  'aria-hidden="true"><path d="M8 2v4"/><path d="M16 2v4"/>',
  '<rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/></svg>'
))

#' Date picker
#'
#' A shadcn date picker: a trigger button that opens a [shad_calendar()] in a
#' popover. Value contract is identical to [shad_calendar()].
#'
#' @inheritParams shad_calendar
#' @param label Optional label (wraps in [shad_form_field()]).
#' @param placeholder Trigger text shown when nothing is selected.
#' @param presets Optional quick-range rail, only valid with `mode = "range"`.
#'   A named list; names are the button labels and each value is either a
#'   keyword (`"today"`, `"yesterday"`, `"this-week"`, `"this-month"`,
#'   `"last-month"`, `"this-year"`), an integer `N` meaning the last `N` days,
#'   or a length-2 `Date` vector giving an explicit start and end.
#'   [shad_date_presets()] returns a ready-made set.
#' @param width CSS width.
#' @returns A date-picker tag.
#' @family shadshiny tier-2 components
#' @examples
#' shad_date_picker("d", label = "Date")
#' shad_date_picker("range", mode = "range")
#' shad_date_picker("dob", label = "Date of birth", caption_layout = "dropdown")
#' @export
shad_date_picker <- function(inputId, label = NULL, value = NULL,
                             mode = c("single", "range"),
                             placeholder = "Pick a date", min = NULL, max = NULL,
                             presets = NULL,
                             caption_layout = c("label", "dropdown",
                                                "dropdown-months", "dropdown-years"),
                             year_range = NULL,
                             disabled = FALSE, width = NULL, class = NULL, ...) {
  value <- shiny::restoreInput(id = inputId, default = value)
  mode <- arg_match_shad(mode, c("single", "range"), "mode")
  if (!is.null(presets) && mode != "range") {
    stop("`presets` is only valid with `mode = \"range\"` in shad_date_picker().",
         call. = FALSE)
  }
  presets_tag <- if (!is.null(presets)) .shad_build_presets(presets)
  # Inner calendar is unbound (no id); the date-picker root is the Shiny input.
  cal <- shad_calendar(
    inputId = NULL, value = value, mode = mode, min = min, max = max,
    caption_layout = caption_layout, year_range = year_range,
    week_starts_on = if (mode == "range") 1 else 0
  )

  wrapped <- !is.null(label)
  root <- do.call(htmltools::tags$div, c(
    list(
      class = shad_class("shad-date-picker", extra = if (!wrapped) class),
      `data-shad` = "date-picker",
      id = inputId,
      style = width_style(width),
      ...
    ),
    list(
      htmltools::tags$button(
        type = "button", class = "shad-date-picker__trigger",
        `data-placeholder` = if (is.null(value)) NA else NULL,
        disabled = flag_attr(disabled),
        .shad_date_picker_icon,
        htmltools::tags$span(class = "shad-date-picker__value", placeholder)
      ),
      htmltools::tags$div(
        class = "shad-date-picker__content shad-anim-pop", hidden = NA,
        presets_tag, cal
      )
    )
  ))

  if (!wrapped) return(with_deps(root))
  shad_form_field(root, label = label, class = class)
}
