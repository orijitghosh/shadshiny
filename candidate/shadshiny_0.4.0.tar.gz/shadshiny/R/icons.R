# Inline Lucide icon registry -------------------------------------------------
# Structural icons are embedded directly in component anatomy; this registry
# powers the exported shad_icon() helper and leading/trailing icons on buttons,
# badges, menu items, etc. All icons are 24x24, stroke-width 2, currentColor,
# matching the markup baked into inst/assets anatomy files. The paths are
# Lucide's (ISC; some derive from Feather, MIT): see inst/COPYRIGHTS.

.shad_icon_paths <- list(
  "chevron-down"      = '<path d="m6 9 6 6 6-6"/>',
  "chevron-up"        = '<path d="m18 15-6-6-6 6"/>',
  "chevron-left"      = '<path d="m15 18-6-6 6-6"/>',
  "chevron-right"     = '<path d="m9 18 6-6-6-6"/>',
  "chevrons-up-down"  = '<path d="m7 15 5 5 5-5"/><path d="m7 9 5-5 5 5"/>',
  "chevrons-left-right" = '<path d="m9 7-5 5 5 5"/><path d="m15 7 5 5-5 5"/>',
  "check"             = '<path d="M20 6 9 17l-5-5"/>',
  "x"                 = '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
  "minus"             = '<path d="M5 12h14"/>',
  "plus"              = '<path d="M5 12h14"/><path d="M12 5v14"/>',
  "circle"            = '<circle cx="12" cy="12" r="10"/>',
  "dot"               = '<circle cx="12" cy="12" r="4" fill="currentColor" stroke="none"/>',
  "search"            = '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
  "calendar"          = '<path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/>',
  "more-horizontal"   = '<circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/>',
  "more-vertical"     = '<circle cx="12" cy="12" r="1"/><circle cx="12" cy="5" r="1"/><circle cx="12" cy="19" r="1"/>',
  "mail"              = '<rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>',
  "terminal"          = '<polyline points="4 17 10 11 4 5"/><line x1="12" x2="20" y1="19" y2="19"/>',
  "circle-alert"      = '<circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/>',
  "circle-check"      = '<circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/>',
  "info"              = '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/>',
  "triangle-alert"    = '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
  "loader"            = '<path d="M21 12a9 9 0 1 1-6.219-8.56"/>',
  "arrow-left"        = '<path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>',
  "arrow-right"       = '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
  "menu"              = '<line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/>',
  "panel-left"        = '<rect width="18" height="18" x="3" y="3" rx="2"/><path d="M9 3v18"/>',
  "file"              = '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/>',
  "folder"            = '<path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/>',
  "clock"             = '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
  "arrow-up"          = '<path d="m5 12 7-7 7 7"/><path d="M12 19V5"/>',
  "arrow-down"        = '<path d="M12 5v14"/><path d="m19 12-7 7-7-7"/>',
  "chevrons-down-up"  = '<path d="m7 20 5-5 5 5"/><path d="m7 4 5 5 5-5"/>',
  "circle-x"          = '<circle cx="12" cy="12" r="10"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/>',
  "circle-plus"       = '<circle cx="12" cy="12" r="10"/><path d="M8 12h8"/><path d="M12 8v8"/>',
  "circle-help"       = '<circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><path d="M12 17h.01"/>',
  "home"              = '<path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
  "user"              = '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
  "users"             = '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
  "settings"          = '<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
  "bell"              = '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>',
  "trash"             = '<path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/>',
  "pencil"            = '<path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4Z"/>',
  "download"          = '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/>',
  "upload"            = '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/>',
  "external-link"     = '<path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>',
  "eye"               = '<path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/>',
  "eye-off"           = '<path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"/><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"/><path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"/><line x1="2" x2="22" y1="2" y2="22"/>',
  "lock"              = '<rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  "unlock"            = '<rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 9.9-1"/>',
  "heart"             = '<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/>',
  "star"              = '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
  "bookmark"          = '<path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>',
  "filter"            = '<polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/>',
  "refresh-cw"        = '<path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/>',
  "log-out"           = '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/>',
  "log-in"            = '<path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" x2="3" y1="12" y2="12"/>',
  "copy"              = '<rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
  "clipboard"         = '<rect width="8" height="4" x="8" y="2" rx="1" ry="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/>',
  "save"              = '<path d="M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"/><path d="M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7"/><path d="M7 3v4a1 1 0 0 0 1 1h7"/>',
  "sun"               = '<circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/>',
  "moon"              = '<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>',
  "image"             = '<rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/>',
  "link"              = '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
  "phone"             = '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>',
  "map-pin"           = '<path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"/><circle cx="12" cy="10" r="3"/>',
  "credit-card"       = '<rect width="20" height="14" x="2" y="5" rx="2"/><line x1="2" x2="22" y1="10" y2="10"/>',
  "shopping-cart"     = '<circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/>',
  "package"           = '<path d="M11 21.73a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73z"/><path d="M3.29 7 12 12l8.71-5"/><path d="M12 22V12"/>',
  "bar-chart"         = '<line x1="12" x2="12" y1="20" y2="10"/><line x1="18" x2="18" y1="20" y2="4"/><line x1="6" x2="6" y1="20" y2="16"/>',
  "activity"          = '<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>',
  "zap"               = '<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>',
  "message-circle"    = '<path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/>',
  "send"              = '<path d="M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z"/><path d="m21.854 2.147-10.94 10.939"/>',
  "paperclip"         = '<path d="m21.44 11.05-9.19 9.19a6 6 0 0 1-8.49-8.49l8.57-8.57A4 4 0 1 1 18 8.84l-8.59 8.57a2 2 0 0 1-2.83-2.83l8.49-8.48"/>',
  "thumbs-up"         = '<path d="M7 10v12"/><path d="M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2a3.13 3.13 0 0 1 3 3.88Z"/>',
  "globe"             = '<circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/>',
  "github"            = '<path d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4"/><path d="M9 18c-4.51 2-5-2-7-2"/>'
)

#' Inline Lucide icon
#'
#' Returns a 24x24 inline SVG (stroke-width 2, `currentColor`) matching the
#' icon markup embedded throughout the shadshiny asset bundle. Use it for
#' leading/trailing icons on buttons, menu items, and other slots that accept
#' an `icon` argument.
#'
#' @param name Icon name. See [shad_icon_names()] for the available set.
#' @param class CSS class(es) for the `<svg>`. Defaults to `"shad-icon"`.
#' @param ... Additional attributes for the `<svg>` (e.g. `aria-label`).
#'
#' @returns An [htmltools::HTML()] SVG string.
#' @family shadshiny utilities
#' @examples
#' shad_icon("check")
#' shad_icon("chevron-down", class = "shad-select__chevron")
#' @export
shad_icon <- function(name, class = "shad-icon", ...) {
  if (is.null(name) || !name %in% names(.shad_icon_paths)) {
    stop(sprintf(
      "Unknown icon `%s`. Available icons: %s.",
      if (is.null(name)) "NULL" else name,
      paste(names(.shad_icon_paths), collapse = ", ")
    ), call. = FALSE)
  }
  attrs <- list(...)
  base <- list(
    class = class,
    viewBox = "0 0 24 24",
    fill = "none",
    stroke = "currentColor",
    `stroke-width` = "2",
    `stroke-linecap` = "round",
    `stroke-linejoin` = "round"
  )
  if (!"aria-label" %in% names(attrs)) base[["aria-hidden"]] <- "true"
  svg <- do.call(
    htmltools::tags$svg,
    c(base, attrs, list(htmltools::HTML(.shad_icon_paths[[name]])))
  )
  # Carry the asset bundle so a standalone icon still gets its `.shad-icon`
  # sizing CSS when it is the only shadshiny output on a page. When nested in
  # another component the duplicate dependency is de-duplicated by htmltools.
  with_deps(svg)
}

#' Available shadshiny icon names
#' @returns A character vector of icon names accepted by [shad_icon()].
#' @family shadshiny utilities
#' @examples
#' shad_icon_names()
#' @export
shad_icon_names <- function() {
  names(.shad_icon_paths)
}

#' Use an arbitrary SVG as a shadshiny icon
#'
#' Wrap a raw `<svg>` string (e.g. any Lucide glyph pasted from
#' \url{https://lucide.dev}) with the `.shad-icon` sizing class, so icons beyond
#' the built-in set can be used anywhere a [shad_icon()] is accepted.
#' Because string input is inserted as trusted raw SVG, never pass untrusted or
#' user-controlled content to this function.
#'
#' @param svg A raw `<svg>...</svg>` string, or an htmltools tag.
#' @param class CSS classes to apply (default `"shad-icon"`).
#' @returns An icon tag carrying the shadshiny asset dependency.
#' @family shadshiny utilities
#' @examples
#' shad_icon_raw('<svg viewBox="0 0 24 24"><path d="M5 12h14"/></svg>')
#' @export
shad_icon_raw <- function(svg, class = "shad-icon") {
  if (is_tag_like(svg)) {
    return(with_deps(htmltools::tagAppendAttributes(svg, class = class)))
  }
  svg <- as.character(svg)
  if (!grepl("^\\s*<svg", svg)) {
    stop("`svg` must be an <svg> string or an htmltools tag.", call. = FALSE)
  }
  # inject the sizing class into the opening <svg ...> tag (only if absent)
  if (!grepl("<svg[^>]*\\sclass=", svg)) {
    svg <- sub("<svg", sprintf('<svg class="%s"', class), svg)
  }
  with_deps(htmltools::tagList(htmltools::HTML(svg)))
}

# Normalise an `icon` argument (name string or tag) into a tag/HTML, or NULL.
#' @noRd
resolve_icon <- function(icon, class = "shad-icon") {
  if (is.null(icon)) return(NULL)
  if (is.character(icon) && length(icon) == 1) return(shad_icon(icon, class = class))
  icon
}
