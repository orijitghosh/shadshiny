## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
library(shadshiny)

## -----------------------------------------------------------------------------
events <- function(prompt, history) {
  list(
    list(type = "text_delta", text = paste("You asked:", prompt$text)),
    list(type = "source", title = "Documentation", url = "https://example.org"),
    list(type = "status", text = "Public summary only"),
    list(type = "done")
  )
}

